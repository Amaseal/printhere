<script>
	import '@picocss/pico';
	import '../../../../styles.css';
</script>

<slot />
