<svelte:head>
	<title>Data policies</title>
	<meta name="description" content="Printhere.eu's data policies" />
</svelte:head>

<section>
	<div class="container">
		<h1>Data protection</h1>
		<p>
			At PrintHere.eu, we take data protection and privacy very seriously. We understand that your
			personal data is important and we want to ensure that it is kept safe and secure at all times.
			This data protection policy explains how we collect, use, store and delete your personal
			information.
		</p>
		<h2>Collection and Use of Personal Information</h2>
		<p>
			When you place an order on our website, we collect personal information such as your name,
			email address, phone number, and shipping address. This information is necessary to process
			your order and deliver your printed materials to you. We may also use your email address to
			send you updates on your order or to inform you of promotions or special offers.
		</p>
		<p>
			We will not share your personal information with any third parties unless required to do so by
			law.
		</p>
		<h2>Storage and Deletion of Personal Information</h2>
		<p>
			We store your personal information only for as long as it is necessary to complete your order
			and for a reasonable period of time thereafter in order to handle any issues or disputes that
			may arise. Once that period has passed, we will delete your personal information from our
			system.
		</p>
		<h2>Your Rights</h2>
		<p>
			You have the right to access the personal information we hold about you and to ask for it to
			be corrected, updated, or deleted. You can do this by contacting our customer service team. If
			you believe that we have not complied with our obligations under data protection law, you also
			have the right to make a complaint to the relevant data protection authority.
		</p>
		<h2>Conclusion</h2>
		<p>
			At PrintHere.eu, we are committed to protecting your personal information and ensuring that it
			is only used for the purposes for which it was provided. We will never sell or share your
			personal information with third parties, and we will delete it once it is no longer necessary
			for the purposes for which it was collected.
		</p>
	</div>
</section>

<style>
	.container {
		padding-top: 100px;
	}
</style>
